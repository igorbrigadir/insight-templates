To Update your poster, get the latest version from here, overwrite the files (everything apart from example_*), recompile, & export your pdf again:

beamerposter.sty
beamerthemeInsight.sty
insightcolours.sty
footer-blank.pdf
header-blank.pdf
insightlogo.pdf
institutions.pdf
meshpattern1.pdf
meshpattern2.pdf
page-back.pdf
sfi.pdf